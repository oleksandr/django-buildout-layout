TODO
====

* Add support for multiple levels of inheritance to ``InheritanceManager``.
