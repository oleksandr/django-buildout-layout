.. contents::

- Code repository: https://github.com/collective/mr.scripty
- Questions and comments to https://github.com/collective/mr.scripty
- Report bugs at https://github.com/collective/mr.scripty

