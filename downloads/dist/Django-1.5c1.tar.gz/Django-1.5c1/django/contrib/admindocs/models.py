# Empty models.py to allow for specifying admindocs as a test label.
