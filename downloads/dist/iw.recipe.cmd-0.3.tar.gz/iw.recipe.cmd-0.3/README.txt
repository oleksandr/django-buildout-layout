.. contents::

.. Note to recipe author!
   ---------------------
   Update the following URLs to point to your:
   
   - code repository
   - bug tracker 
   - questions/comments feedback mail 
   (do not set a real mail, to avoid spams)

   Or remove it if not used.

- Code repository: https://ingeniweb.svn.sourceforge.net/svnroot/ingeniweb/iw.recipe.cmd/trunk
- Questions and comments to support@ingeniweb.com
- Report bugs at http://trac.ingeniweb.com/

